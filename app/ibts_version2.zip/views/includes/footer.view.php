 
<footer> 
    <section class="pd-bottom20px pd-top20px brand-bg-blue">  
        <p class="ff-body brand-cl-skyblue txtAli-center">All right reserved | <b>IBT Society</b> @2023
        </p>
    </section>
</footer>

 <!--header property--> 
 <script src="<?=ROOT?>/assets/js/header.js"></script>
 <script src="<?=ROOT?>/assets/js/global.js"></script>

   
</body> 
</html>